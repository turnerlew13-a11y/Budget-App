# Pocket Budget Chrome Extension (2026)
## Installation Instructions:
1. Extract this .zip file to a permanent folder on your computer.
2. Open Google Chrome and visit: chrome://extensions/
3. Turn on "Developer mode" in the top-right corner.
4. Click "Load unpacked" in the top-left corner.
5. Select the extracted folder containing manifest.json and index.html.
6. Pin the extension to your toolbar for quick daily budgeting!